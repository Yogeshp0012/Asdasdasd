# app/tools/hitl.py

import uuid
from typing import Dict, Optional
from pydantic import BaseModel, Field
from app.schemas.partner import HumanFeedback
from app.utils.logger import get_logger
from app.db.session import AsyncSession
from app.models.partner import FeedbackLog

logger = get_logger("hitl")


class HITLRequest(BaseModel):
    validation_id: uuid.UUID
    partner_name: str
    partner_address: str
    confidence_score: float = Field(..., ge=0.0, le=1.0)
    validation_data: dict
    child_entities: Optional[list] = []
    source_breakdown: Dict[str, float]


class HITLCoordinator:
    """
    Enhanced Human-in-the-Loop coordinator with:
    - Async database integration
    - Confidence-based escalation
    - Feedback-driven validation improvement
    - Audit logging
    """

    def __init__(self, confidence_threshold: float = 0.85):
        self.confidence_threshold = confidence_threshold
        self.pending_requests: Dict[uuid.UUID, HITLRequest] = {}

    async def escalate_validation(
            self,
            db: AsyncSession,
            validation_data: dict,
            confidence_score: float,
            sources: Dict[str, float]
    ) -> Optional[uuid.UUID]:  # Fixed return type
        """
        Create HITL request if confidence below threshold
        Returns escalation ID if triggered, None otherwise
        """
        if confidence_score >= self.confidence_threshold:
            return None

        request_id = uuid.uuid4()
        hitl_request = HITLRequest(
            validation_id=request_id,
            partner_name=validation_data.get('partner_name'),
            partner_address=validation_data.get('partner_address'),
            confidence_score=confidence_score,
            validation_data=validation_data,
            child_entities=validation_data.get('child_entities', []),
            source_breakdown=sources
        )

        # Store in memory and DB
        self.pending_requests[request_id] = hitl_request
        await self._log_escalation(db, hitl_request)

        logger.warning(f"HITL escalation {request_id} triggered with confidence {confidence_score:.2f}")
        return request_id

    async def submit_feedback(
            self,
            db: AsyncSession,
            feedback: HumanFeedback,
            escalation_id: uuid.UUID
    ) -> Dict:
        """
        Process human feedback and update validation outcomes
        """
        try:
            # Store feedback in database
            feedback_log = FeedbackLog(
                partner_id=feedback.partner_id,
                user_id=feedback.user_id,
                decision=feedback.decision.value,
                comments=feedback.comments,
                corrected_data=feedback.corrected_data
            )
            db.add(feedback_log)
            await db.commit()

            # Update pending request
            request = self.pending_requests.pop(escalation_id, None)
            if request:
                await HITLCoordinator._adjust_confidence_based_on_feedback(db, feedback)

            logger.info(f"Feedback processed for escalation {escalation_id}")
            return {"status": "success", "feedback_id": feedback_log.id}

        except Exception as e:
            logger.error(f"Feedback submission failed: {str(e)}")
            await db.rollback()
            return {"status": "error", "message": str(e)}

    @staticmethod
    async def _log_escalation(db: AsyncSession, request: HITLRequest):
        """Persist escalation details to database"""
        try:
            escalation_record = FeedbackLog(
                validation_id=request.validation_id,
                partner_name=request.partner_name,
                initial_data=request.validation_data,
                confidence_score=request.confidence_score
            )
            db.add(escalation_record)
            await db.commit()
        except Exception as e:
            logger.error(f"Failed to log escalation: {str(e)}")
            await db.rollback()

    @staticmethod
    async def _adjust_confidence_based_on_feedback(db: AsyncSession, feedback: HumanFeedback):
        """Update validation rules based on human input"""
        # Implementation would interact with your validation agents
        # Example: Adjust source credibility scores
        logger.debug(f"Adjusting models based on feedback: {feedback}")
