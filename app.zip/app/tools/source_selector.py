from typing import List, Dict
import tldextract
from app.tools.web_search_tool import WebSearchTool
from app.utils.logger import get_logger
from tenacity import retry, stop_after_attempt

logger = get_logger("source_selector")

class SourceSelector:
    """
    Dynamic source selection with:
    - Automatic discovery of relevant sources
    - Trust scoring based on domain authority
    - Context-aware relevance calculation
    - Continuous relevance updates
    """

    TRUSTED_TLDS = {'gov', 'edu', 'mil', 'int'}
    TRUSTED_DOMAINS = {'wikipedia.org', 'companieshouse.gov.uk', 'sec.gov'}

    def __init__(self, initial_query: str = "partner verification sources"):
        self.web_search = WebSearchTool(max_results=20)
        self.source_cache = {}  # {domain: relevance_score}
        self._bootstrap_sources(initial_query)

    @retry(stop=stop_after_attempt(3))
    def _bootstrap_sources(self, query: str):
        """Seed initial sources through web search"""
        results = self.web_search.search(query)
        for result in results:
            domain = tldextract.extract(result['link']).registered_domain
            self._update_source_score(domain, result['trust_score'])

    def _update_source_score(self, domain: str, score: float):
        """Update relevance with exponential moving average"""
        current = self.source_cache.get(domain, 0.0)
        new_score = 0.7 * current + 0.3 * score
        self.source_cache[domain] = min(max(new_score, 0.0), 1.0)

    def _calculate_domain_trust(self, domain: str) -> float:
        """Calculate base trust score for a domain"""
        ext = tldextract.extract(domain)
        if ext.suffix in self.TRUSTED_TLDS:
            return 0.9
        if domain in self.TRUSTED_DOMAINS:
            return 0.8
        if any(p in domain for p in ['news', 'blog']):
            return 0.4
        return 0.6  # Default neutral score

    def select_sources(self, query: str, max_sources=5) -> List[Dict]:
        """
        Dynamically discover and rank sources for a query
        Returns: List of {domain, relevance_score, last_used}
        """
        # 1. Find new potential sources through web search
        search_results = self.web_search.search(query)
        discovered_domains = {
            tldextract.extract(r['link']).registered_domain
            for r in search_results
        }

        # 2. Update cache with discovered domains
        for domain in discovered_domains:
            if domain not in self.source_cache:
                base_trust = self._calculate_domain_trust(domain)
                self.source_cache[domain] = base_trust

        # 3. Sort by relevance score
        sorted_sources = sorted(
            [{"domain": k, "score": v} for k, v in self.source_cache.items()],
            key=lambda x: -x['score']
        )

        # 4. Return top sources meeting threshold
        return sorted_sources[:max_sources]

    def update_from_validation(self, domain: str, was_helpful: bool):
        """Adjust scores based on validation outcomes"""
        adjustment = 0.1 if was_helpful else -0.2
        current = self.source_cache.get(domain, 0.5)
        self.source_cache[domain] = min(max(current + adjustment, 0.0), 1.0)
        logger.info(f"Updated {domain} score to {self.source_cache[domain]}")

# Usage Example
if __name__ == "__main__":
    selector = SourceSelector()
    sources = selector.select_sources("Example Corp subsidiaries", max_sources=3)
    print("Top sources for validation:")
    for src in sources:
        print(f"- {src['domain']} (score: {src['score']:.2f})")
