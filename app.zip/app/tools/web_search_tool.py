import requests
from duckduckgo_search import DDGS
from urllib.parse import urlparse
import logging
from tenacity import retry, stop_after_attempt, wait_exponential
from app.utils.logger import get_logger

logger = get_logger("web_search")

class WebSearchTool:
    """
    Enhanced web search with:
    - Trusted source prioritization (gov, edu, official portals)
    - Rate limiting and retries
    - Domain reliability scoring
    - API error handling
    """

    TRUSTED_DOMAINS = {
        'gov', 'edu', 'wikipedia.org',
        'companieshouse.gov.uk', 'sec.gov'
    }

    def __init__(self, max_results=8, min_trust=0.5):
        self.max_results = max_results
        self.min_trust = min_trust
        self.user_agent = "PartnerDataBot/1.0 (+https://yourcompany.com/bot)"

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    def search(self, query: str) -> list[dict]:
        """Search with trust scoring and source filtering"""
        try:
            with DDGS() as ddgs:
                results = []
                for result in ddgs.text(query, max_results=self.max_results*2):
                    processed = self._process_result(result)
                    if processed['trust_score'] >= self.min_trust:
                        results.append(processed)
                        if len(results) >= self.max_results:
                            break
                return sorted(results, key=lambda x: -x['trust_score'])

        except Exception as e:
            logger.error(f"Search failed for '{query}': {str(e)}")
            return []

    def _process_result(self, result: dict) -> dict:
        """Enrich results with trust metrics"""
        domain = self._extract_domain(result.get('href', ''))
        return {
            'title': result.get('title', ''),
            'link': result.get('href', ''),
            'snippet': result.get('body', ''),
            'domain': domain,
            'trust_score': self._calculate_trust_score(domain),
            'source_type': self._classify_source(domain)
        }

    def _extract_domain(self, url: str) -> str:
        """Extract registered domain from URL"""
        try:
            parsed = urlparse(url)
            if not parsed.netloc:
                return ''
            parts = parsed.netloc.split('.')
            return '.'.join(parts[-2:]) if len(parts) >=2 else parsed.netloc
        except:
            return ''

    def _calculate_trust_score(self, domain: str) -> float:
        """Score domains based on trustworthiness"""
        if any(td in domain for td in self.TRUSTED_DOMAINS):
            return 0.9
        if domain.endswith('.gov') or domain.endswith('.edu'):
            return 0.8
        if 'wikipedia' in domain:
            return 0.7
        return 0.5  # Default for unknown domains

    def _classify_source(self, domain: str) -> str:
        """Categorize source type for agents"""
        if 'wikipedia' in domain:
            return 'encyclopedia'
        if any(d in domain for d in ['gov', 'edu']):
            return 'official'
        if any(d in domain for d in ['linkedin', 'crunchbase']):
            return 'business'
        return 'general'

# Usage example
if __name__ == "__main__":
    tool = WebSearchTool()
    results = tool.search("Example Corp subsidiaries")
    for r in results[:3]:
        print(f"[{r['source_type'].upper()}] {r['title']}\n{r['snippet']}\n")
