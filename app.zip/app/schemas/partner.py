# app/schemas/partner.py

from __future__ import annotations
from datetime import datetime
from typing import List, Optional, Dict
from pydantic import BaseModel, Field, ConfigDict, UUID4, field_validator
from enum import Enum

class ValidationStatus(str, Enum):
    PENDING = "pending"
    VALID = "valid"
    INVALID = "invalid"
    ESCALATED = "escalated"

class ChildEntity(BaseModel):
    name: str = Field(
        ...,
        json_schema_extra={
            "example": "Subsidiary A",
            "description": "Legal entity name"
        }
    )
    address: str = Field(
        ...,
        json_schema_extra={
            "example": "456 Child St, City",
            "description": "Registered office address"
        }
    )
    validation_status: ValidationStatus = Field(
        default=ValidationStatus.PENDING,
        json_schema_extra={"description": "Current validation state"}
    )
    confidence: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        json_schema_extra={"example": 0.95}
    )
    children: Optional[List["ChildEntity"]] = Field(
        default=None,
        json_schema_extra={"description": "Nested child entities"}
    )

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "name": "Subsidiary A",
                "address": "456 Child St, City",
                "validation_status": "valid",
                "confidence": 0.97,
                "children": []
            }
        }
    )

class PartnerRegistrationRequest(BaseModel):
    partner_name: str = Field(
        ...,
        min_length=3,
        json_schema_extra={
            "example": "Example Corp",
            "description": "Legal business name to register"
        }
    )
    partner_address: str = Field(
        ...,
        min_length=10,
        json_schema_extra={
            "example": "123 Business St, San Javier",
            "description": "Physical business address"
        }
    )
    child_entities: Optional[List[ChildEntity]] = Field(
        default=None,
        json_schema_extra={"description": "Initial child entities, if known"}
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "partner_name": "Example Corp",
                "partner_address": "123 Business St, San Javier",
                "child_entities": [
                    {
                        "name": "Subsidiary A",
                        "address": "456 Child St, City",
                        "validation_status": "pending",
                        "confidence": 0.0,
                        "children": []
                    }
                ]
            }
        }
    )

class ValidationResult(BaseModel):
    validation_step: str = Field(
        ...,
        json_schema_extra={"example": "address_verification"}
    )
    status: ValidationStatus
    confidence: float = Field(..., ge=0.0, le=1.0)
    sources: List[str] = Field(
        default_factory=list,
        json_schema_extra={
            "example": ["companieshouse.gov.uk", "wikipedia.org"],
            "description": "Trusted sources used for validation"
        }
    )
    timestamp: datetime = Field(
        default_factory=datetime.utcnow,
        json_schema_extra={"description": "Validation completion time"}
    )
    triggered_hitl: bool = Field(
        default=False,
        json_schema_extra={"description": "HITL escalation flag"}
    )

class HumanFeedback(BaseModel):
    partner_id: UUID4 = Field(
        ...,
        json_schema_extra={"description": "UUID of partner being reviewed"}
    )
    user_id: UUID4 = Field(
        ...,
        json_schema_extra={"description": "UUID of reviewing staff member"}
    )
    decision: ValidationStatus
    comments: Optional[str] = Field(
        default=None,
        max_length=500,
        json_schema_extra={"example": "Address needs verification"}
    )
    corrected_data: Optional[Dict] = Field(
        default=None,
        json_schema_extra={"example": {"address": "Updated address"}}
    )
    timestamp: datetime = Field(
        default_factory=datetime.utcnow,
        json_schema_extra={"description": "Review timestamp"}
    )

class PartnerResponse(BaseModel):
    id: UUID4 = Field(..., json_schema_extra={"description": "Unique partner identifier"})
    partner_name: str = Field(..., json_schema_extra={"example": "Example Corp"})
    partner_address: str = Field(..., json_schema_extra={"example": "123 Business St, San Javier"})
    registration_status: ValidationStatus = Field(
        default=ValidationStatus.PENDING,
        json_schema_extra={"description": "Overall registration status"}
    )
    validation_results: List[ValidationResult] = Field(
        default_factory=list,
        json_schema_extra={"description": "Hierarchical validation outcomes"}
    )
    child_entities: List[ChildEntity] = Field(
        default_factory=list,
        json_schema_extra={"description": "Validated subsidiary structure"}
    )
    feedback_history: List[HumanFeedback] = Field(
        default_factory=list,
        json_schema_extra={"description": "Historical review decisions"}
    )

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "partner_name": "Example Corp",
                "partner_address": "123 Business St, San Javier",
                "registration_status": "valid",
                "validation_results": [
                    {
                        "validation_step": "address_verification",
                        "status": "valid",
                        "confidence": 0.92,
                        "sources": ["geonames.org"],
                        "timestamp": "2024-01-01T12:00:00Z",
                        "triggered_hitl": False
                    }
                ],
                "child_entities": [],
                "feedback_history": []
            }
        }
    )


    @field_validator("partner_name", mode="after")
    @classmethod
    def validate_partner_name(cls, v: str) -> str:
        if not v:
            raise ValueError("Partner name cannot be empty")
        if any(c in r"\/%$#@!^&*()" for c in v):
            raise ValueError("Name contains invalid special characters")
        return v.strip()
