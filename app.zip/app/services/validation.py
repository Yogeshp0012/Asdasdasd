# app/services/validation.py

import logging
from typing import List, Tuple
from app.schemas.partner import ValidationResult, ChildEntity, ValidationStatus
from app.crew import get_partner_validation_crew

logger = logging.getLogger("validation")

async def validate_partner_workflow(
    partner_name: str,
    partner_address: str
) -> Tuple[List[ValidationResult], List[ChildEntity]]:
    """
    Execute the full validation workflow including:
    - Core data validation
    - Child entity discovery
    - Recursive validation of child entities
    """
    try:
        logger.info(f"🚀 Validating {partner_name}")
        crew = get_partner_validation_crew()

        main_result = await crew.kickoff(inputs={
            'partner_name': partner_name,
            'partner_address': partner_address
        })

        child_dicts = main_result.get('child_entities', [])
        child_entities = await _process_child_entities(child_dicts)

        logger.info(f"✅ Successfully validated {partner_name}")
        return [
            ValidationResult(
                validation_step="core_validation",
                status=ValidationStatus.VALID if main_result.get('is_valid') else ValidationStatus.INVALID,
                confidence=main_result.get('confidence', 0.0),
                sources=main_result.get('sources', []),
                triggered_hitl=main_result.get('needs_human_review', False)
            )
        ], child_entities

    except Exception as e:
        logger.error(f"❌ Validation failed for {partner_name}: {str(e)}")
        return _error_result(), []

async def _process_child_entities(
    child_dicts: List[dict],
    recursion_level: int = 0,
    max_depth: int = 3
) -> List[ChildEntity]:
    """Recursive processor with depth control and type safety"""
    if recursion_level >= max_depth:
        logger.warning(f"⏹️ Max recursion depth {max_depth} reached")
        return []

    return [
        await _build_child_entity(child, recursion_level, max_depth)
        for child in child_dicts
    ]

async def _build_child_entity(
    child_data: dict,
    recursion_level: int,
    max_depth: int
) -> ChildEntity:
    """Safe child entity builder with error handling"""
    try:
        child_results, grand_children = await validate_partner_workflow(
            child_data['name'],
            child_data['address']
        )

        return ChildEntity(
            name=child_data['name'],
            address=child_data['address'],
            validation_status=_determine_status(child_results),
            confidence=_max_confidence(child_results),
            children=await _process_child_entities(
                [gc.model_dump() for gc in grand_children],
                recursion_level + 1,
                max_depth
            )
        )
    except Exception as e:
        logger.error(f"🧒 Child validation error: {str(e)}")
        return ChildEntity(
            **child_data,
            validation_status=ValidationStatus.INVALID,
            confidence=0.0,
            children=[]
        )

def _determine_status(results: List[ValidationResult]) -> ValidationStatus:
    """Aggregate validation results"""
    if any(result.status == ValidationStatus.VALID for result in results):
        return ValidationStatus.VALID
    return ValidationStatus.INVALID

def _max_confidence(results: List[ValidationResult]) -> float:
    return max((result.confidence for result in results), default=0.0)

def _error_result() -> List[ValidationResult]:
    """Standard error response"""
    return [ValidationResult(
        validation_step="system",
        status=ValidationStatus.INVALID,
        confidence=0.0,
        sources=[],
        triggered_hitl=True
    )]
