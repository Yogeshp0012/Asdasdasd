# app/services/feedback.py

import logging
from uuid import UUID
from typing import Optional, Dict
from sqlalchemy import select
from app.schemas.partner import HumanFeedback, ValidationStatus, ValidationResult
from app.db.session import AsyncSession
from app.models.partner import Partner, FeedbackLog

logger = logging.getLogger("feedback")

async def process_human_feedback(
    partner_id: UUID,
    feedback: HumanFeedback,
    db: AsyncSession
) -> Partner:
    """
    Process human feedback and update:
    - Partner validation status
    - Confidence scores
    - Corrected data
    """
    try:
        # Get fresh partner instance
        result = await db.execute(
            select(Partner)
            .where(Partner.id == partner_id)
            .execution_options(populate_existing=True)
        )
        partner = result.scalar_one()

        # Update validation results based on feedback
        new_validation = [
            ValidationResult(
                validation_step="human_review",
                status=feedback.decision,
                confidence=1.0,  # Human override gets max confidence
                sources=["human_feedback"],
                triggered_hitl=False
            )
        ]

        # Merge with existing validations
        partner.validation_results = [
            vr for vr in partner.validation_results
            if vr.validation_step != "human_review"
        ] + new_validation

        # Apply data corrections if provided
        if feedback.corrected_data:
            partner.name = feedback.corrected_data.get('name', partner.name)
            partner.address = feedback.corrected_data.get('address', partner.address)
            logger.info(f"Applied corrections to partner {partner_id}")

        # Update overall status
        partner.registration_status = feedback.decision

        # Log feedback
        feedback_log = FeedbackLog(
            partner_id=partner_id,
            user_id=feedback.user_id,
            decision=feedback.decision.value,
            comments=feedback.comments,
            corrected_data=feedback.corrected_data
        )
        db.add(feedback_log)

        await db.commit()
        await db.refresh(partner)

        logger.info(f"Processed feedback for partner {partner_id}")
        return partner

    except Exception as e:
        logger.error(f"Failed processing feedback: {str(e)}")
        await db.rollback()
        raise
