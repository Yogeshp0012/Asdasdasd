# app/models/partner.py

from sqlalchemy import Column, String, JSON, Float
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base
import uuid

Base = declarative_base()


class Partner(Base):
    __tablename__ = "partners"

    id = Column(UUID(as_uuid=True), primary_key=True)
    name = Column(String)
    address = Column(String)
    registration_status = Column(String)
    validation_results = Column(JSON)  # Store validation results
    child_entities = Column(JSON)  # Store child entities

class FeedbackLog(Base):
    __tablename__ = "feedback_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    partner_id = Column(UUID(as_uuid=True), nullable=True)
    user_id = Column(UUID(as_uuid=True), nullable=True)
    decision = Column(String, nullable=True)
    comments = Column(String, nullable=True)
    corrected_data = Column(JSON, nullable=True)
    confidence_score = Column(Float, nullable=True)
    validation_id = Column(UUID(as_uuid=True), nullable=True)
    partner_name = Column(String, nullable=True)
    initial_data = Column(JSON, nullable=True)
