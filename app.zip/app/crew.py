import os
from dotenv import load_dotenv
from crewai import Agent, Crew, Process, Task
from langchain_openai import AzureChatOpenAI
from app.utils.config import load_yaml_config
import logging

# Load environment variables
load_dotenv()

# Load agent and task configs
AGENTS_CONFIG = load_yaml_config("app/config/agents.yaml")
TASKS_CONFIG = load_yaml_config("app/config/tasks.yaml")

# Azure OpenAI LLM setup
llm = AzureChatOpenAI(
    azure_deployment=os.getenv("OPENAI_DEPLOYMENT_NAME"),
    api_version=os.getenv("OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("OPENAI_API_BASE"),
    api_key=os.getenv("OPENAI_API_KEY")
)

def build_agent(agent_key: str) -> Agent:
    config = AGENTS_CONFIG[agent_key]
    return Agent(
        role=config['role'],
        goal=config['goal'],
        backstory=config['backstory'],
        llm=llm,
        verbose=True
    )

def build_task(task_key: str, agent: Agent, context=None, human_input=False) -> Task:
    config = TASKS_CONFIG[task_key]
    return Task(
        description=config['description'],
        expected_output=config['expected_output'],
        agent=agent,
        context=context or [],
        human_input=human_input
    )

def get_partner_validation_crew():
    # Instantiate agents
    planner = build_agent('planner')
    validator = build_agent('validator')
    hitl_coordinator = build_agent('hitl_coordinator')

    # Instantiate tasks
    initiate_validation = build_task('initiate_validation', planner)
    validate_core_data = build_task('validate_core_data', validator, context=[initiate_validation])
    check_child_entities = build_task('check_child_entities', validator, context=[validate_core_data])
    human_review = build_task('human_review', hitl_coordinator, context=[check_child_entities], human_input=True)

    # Build crew with valid parameters
    crew = Crew(
        agents=[planner, validator, hitl_coordinator],
        tasks=[initiate_validation, validate_core_data, check_child_entities, human_review],
        process=Process.sequential,  # Changed from hierarchical
        # full_output removed (no longer a valid parameter)
        manager_llm=llm  # Required for complex workflows
    )
    return crew

def run_partner_validation_workflow(partner_name: str, partner_address: str):
    crew = get_partner_validation_crew()
    try:
        result = crew.kickoff(inputs={
            'partner_name': partner_name,
            'partner_address': partner_address
        })
        return result
    except Exception as e:
        logging.error(f"Partner validation workflow failed: {e}")
        return {"error": str(e)}

if __name__ == "__main__":
    res = run_partner_validation_workflow("Example Corp", "123 Business St, San Javier")
    print(res)
