# app/api/endpoints.py

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List
from uuid import UUID

from app.schemas.partner import (
    PartnerRegistrationRequest,
    PartnerResponse,
    HumanFeedback,
    ValidationStatus,
    ValidationResult,
    ChildEntity,
)
from app.db.session import get_db
from app.models.partner import Partner, FeedbackLog
from app.services.validation import validate_partner_workflow  # Uncomment when implemented

router = APIRouter()

@router.post("/api/partner/register", response_model=PartnerResponse, status_code=status.HTTP_201_CREATED)
async def register_partner(
    request: PartnerRegistrationRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Register a new business partner and trigger validation.
    """
    # Save partner to DB
    partner = Partner(
        name=request.partner_name,
        address=request.partner_address
    )
    db.add(partner)
    await db.commit()
    await db.refresh(partner)

    # Here you would trigger the CrewAI validation workflow asynchronously
    validation_results, child_entities = await validate_partner_workflow(partner.name, partner.address)
    # For now, return dummy data

    response = PartnerResponse(
        id=partner.id,
        partner_name=partner.name,
        partner_address=partner.address,
        registration_status=ValidationStatus.PENDING,
        validation_results=validation_results,
        child_entities=child_entities,
        feedback_history=[]
    )
    return response

@router.get("/api/partner/{partner_id}", response_model=PartnerResponse)
async def get_partner(partner_id: UUID, db: AsyncSession = Depends(get_db)):
    """
    Retrieve partner details and validation status.
    """
    result = await db.execute(select(Partner).where(Partner.id == partner_id))
    partner = result.scalar_one_or_none()
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")

    # Fetch feedback logs
    feedback_result = await db.execute(
        select(FeedbackLog).where(FeedbackLog.partner_id == partner_id)
    )
    feedback_logs = feedback_result.scalars().all()

    # TODO: Fetch validation_results and child_entities from your validation system
    validation_results: List[ValidationResult] = []
    child_entities: List[ChildEntity] = []

    return PartnerResponse(
        id=partner.id,
        partner_name=partner.name,
        partner_address=partner.address,
        registration_status=ValidationStatus.PENDING,
        validation_results=validation_results,
        child_entities=child_entities,
        feedback_history=feedback_logs or []
    )

@router.post("/api/partner/{partner_id}/feedback", status_code=status.HTTP_201_CREATED)
async def submit_feedback(
    partner_id: UUID,
    feedback: HumanFeedback,
    db: AsyncSession = Depends(get_db)
):
    """
    Submit human feedback for a partner (HITL).
    """
    result = await db.execute(select(Partner).where(Partner.id == partner_id))
    partner = result.scalar_one_or_none()
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")

    feedback_log = FeedbackLog(
        partner_id=partner_id,
        user_id=feedback.user_id,
        decision=feedback.decision.value,
        comments=feedback.comments,
        corrected_data=feedback.corrected_data,
    )
    db.add(feedback_log)
    await db.commit()

    return {"message": "Feedback received."}
