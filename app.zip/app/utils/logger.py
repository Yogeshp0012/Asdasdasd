# app/utils/logger.py

from loguru import logger
import sys
import os

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

logger.remove()  # Remove default handler
logger.add(sys.stdout, level=LOG_LEVEL, format="{time} {level} {message}")

def get_logger(name=None):
    """
    Returns a logger instance with an optional name.
    """
    return logger.bind(name=name) if name else logger
