# app/utils/config.py

import yaml
import os
from dotenv import load_dotenv
from pathlib import Path
from typing import Any, Optional
from functools import lru_cache

load_dotenv()  # Load .env file


@lru_cache(maxsize=32)
def load_yaml_config(path: str | Path) -> dict[str, Any]:
    """
    Load and cache YAML configuration files with validation.

    Args:
        path: Path to YAML config file

    Returns:
        Parsed configuration dictionary

    Raises:
        FileNotFoundError: If config file missing
        yaml.YAMLError: For invalid YAML syntax
    """
    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    try:
        with config_path.open("r") as f:
            return yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise yaml.YAMLError(f"Invalid YAML in {config_path}: {e}")


def get_env_variable(key: str, default: Optional[str] = None) -> str:
    """
    Safely get required environment variables.

    Args:
        key: Environment variable name
        default: Optional default value

    Returns:
        Environment variable value

    Raises:
        ValueError: If variable not found and no default provided
    """
    value = os.getenv(key, default)
    if value is None:
        raise ValueError(f"Missing required environment variable: {key}")
    return value
