from fastapi import FastAPI
from app.api.v1.endpoints import partner

app = FastAPI(title="Partner Data Management System")

app.include_router(partner.router, prefix="/api/v1/partners", tags=["partners"])
