from pydantic import BaseModel, EmailStr
from typing import Optional, List

class PartnerValidationRequest(BaseModel):
    """
    Request model for validating a partner (company) name and optional address.
    """
    name: str
    address: Optional[str] = None
    human_feedback: Optional[str] = None

class QAReport(BaseModel):
    """
    Optional quality assurance/audit report for validation process.
    """
    methodology_score: Optional[float] = None
    reproducibility_score: Optional[float] = None
    recommendations: Optional[List[str]] = None

class EntityValidationResult(BaseModel):
    """
    Unified validation result for a partner or any child entity, supporting recursion.
    """
    name: str
    input_address: Optional[str] = None
    validated_address: Optional[str] = None
    headquarters_address: Optional[str] = None
    is_match: Optional[bool] = None
    confidence: float
    sources: List[str]
    reasoning: str
    hitl_required: Optional[bool] = None
    human_feedback: Optional[str] = None
    qa_report: Optional[QAReport] = None
    child_entities: Optional[List['EntityValidationResult']] = []

    class Config:
        orm_mode = True

EntityValidationResult.update_forward_refs()

class PartnerBase(BaseModel):
    """
    Base model for partner CRUD operations.
    """
    name: str
    email: EmailStr

class PartnerCreate(PartnerBase):
    pass

class Partner(PartnerBase):
    id: int

    class Config:
        orm_mode = True

class ValidationSettings(BaseModel):
    """
    Optional settings for controlling validation thresholds and research iterations.
    """
    VALID_CONFIDENCE_THRESHOLD: float = 0.8
    TRUSTED_SOURCE_MINIMUM: int = 2
    MAX_RESEARCH_ITERATIONS: int = 5
