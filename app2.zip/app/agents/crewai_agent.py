import re
import json
from typing import Optional, List, Dict, Any, Set
import requests
from bs4 import BeautifulSoup
from duckduckgo_search import DDGS

from crewai import Agent, LLM, Task, Crew
from app.core.config import settings

azure_llm = LLM(
    model=f"azure/{settings.AZURE_OPENAI_DEPLOYMENT}",
    api_key=settings.AZURE_OPENAI_KEY,
    base_url=settings.AZURE_OPENAI_ENDPOINT,
    api_version=settings.AZURE_OPENAI_API_VERSION,
    temperature=0.2,
    max_tokens=1024
)

class DynamicSearchTool:
    def run(self, query: str, max_results: int = 10) -> List[dict]:
        with DDGS() as ddgs:
            return list(ddgs.text(query, max_results=max_results))

class WebScrapeTool:
    def run(self, url: str) -> str:
        try:
            resp = requests.get(url, timeout=5)
            soup = BeautifulSoup(resp.text, "html.parser")
            paragraphs = soup.find_all("p")
            text = " ".join([p.get_text() for p in paragraphs])
            return text[:1000]
        except Exception as e:
            return f"Error scraping {url}: {e}"

search_tool = DynamicSearchTool()
scrape_tool = WebScrapeTool()

planner = Agent(
    role="Validation Strategist",
    goal="Plan dynamic validation and address verification for a company using web sources.",
    backstory="Expert in designing adaptive validation workflows and source credibility frameworks.",
    llm=azure_llm
)

researcher = Agent(
    role="Intelligence Researcher",
    goal="Execute web investigations for company and address validation using LLM-guided search.",
    backstory="Skilled in information retrieval and source triangulation.",
    llm=azure_llm
)

analyst = Agent(
    role="Credibility Analyst",
    goal="Evaluate source trustworthiness, address validity, and content using AI.",
    backstory="Expert in information verification, address validation, and trust assessment.",
    llm=azure_llm
)

quality_control = Agent(
    role="Validation Auditor",
    goal="Ensure process integrity and incorporate human feedback.",
    backstory="Meticulous validation process reviewer.",
    llm=azure_llm
)

def get_child_entities(name: str, researcher_agent) -> list:
    # Define a CrewAI task for fetching child entities
    child_entities_task = Task(
        description=f"""
        Find the child entities (subsidiaries, branches) of the company named '{name}'.
        Use web search and LLM reasoning to identify names and addresses of child entities.
        Output ONLY valid JSON in this format:
        [
          {{"name": "Child Company 1", "address": "Address 1"}},
          {{"name": "Child Company 2", "address": "Address 2"}}
        ]
        Do not include any explanation or text outside the JSON.
        """,
        agent=researcher_agent,  # Should have web search and LLM tools
        expected_output="JSON list of child entities with name and address."
    )
    # Run the CrewAI task
    crew = Crew(agents=[researcher_agent], tasks=[child_entities_task])
    result = crew.kickoff()

    # Parse the JSON output
    def extract_json(raw):
        try:
            return json.loads(raw)
        except Exception:
            match = re.search(r'\[.*\]', raw, re.DOTALL)
            if match:
                return json.loads(match.group(0))
            return []
    return extract_json(result.raw)

def validate_partner_name_agentic(
    name: str,
    address: Optional[str] = None,
    human_feedback: Optional[str] = None,
    max_results: int = 10
):
    planning_task = Task(
        description=f"""
Plan validation for company '{name}' and address '{address if address else 'N/A'}'.
Include steps to:
- Search for official headquarters and other addresses.
- If address is provided, validate it against official addresses.
- If address is not provided, fetch headquarters address.
Output ONLY valid JSON:
{{
  "search_queries": [<string>],
  "validation_strategy": <string>
}}
Do not include any explanation or text outside JSON.
""",
        agent=planner,
        expected_output="JSON with search_queries and validation_strategy."
    )

    research_task = Task(
        description=f"""
Using the search queries, find headquarters and other official addresses for '{name}'.
Output ONLY valid JSON:
{{
  "headquarters_address": <string>,
  "other_addresses": [<string>],
  "sources": [<string>]
}}
Do not include any explanation or text outside JSON.
""",
        agent=researcher,
        expected_output="JSON with headquarters_address, other_addresses, sources.",
        context=[planning_task]
    )

    analyst_task = Task(
        description=f"""
Given company '{name}', user input address '{address if address else ''}', and found addresses:
- If input address is provided, check if it matches headquarters or any official address (allow for minor variations).
- If not provided, return headquarters address.
- Provide a confidence score (0-1), is_match, and reasoning.
- Indicate if human-in-the-loop (HITL) is needed.
Output ONLY valid JSON:
{{
  "input_address": <string or null>,
  "validated_address": <string or null>,
  "headquarters_address": <string>,
  "is_match": <true/false/null>,
  "confidence": <float>,
  "sources": [<string>],
  "reasoning": <string>,
  "hitl_required": <true/false>
}}
Do not include any explanation or text outside JSON.
""",
        agent=analyst,
        expected_output="JSON with input_address, validated_address, headquarters_address, is_match, confidence, sources, reasoning, hitl_required.",
        context=[research_task]
    )

    qa_task = Task(
        description=f"""
Review the validation for '{name}'.
Integrate human feedback: {human_feedback if human_feedback else 'No feedback provided'}.
Output ONLY valid JSON:
{{
  "qa_notes": <string>
}}
Do not include any explanation or text outside JSON.
""",
        agent=quality_control,
        expected_output="JSON with qa_notes.",
        context=[analyst_task]
    )

    crew = Crew(
        agents=[planner, researcher, analyst, quality_control],
        tasks=[planning_task, research_task, analyst_task, qa_task],
        verbose=True
    )
    result = crew.kickoff()

    def extract_json(raw):
        try:
            return json.loads(raw)
        except Exception:
            match = re.search(r'\{.*\}', raw, re.DOTALL)
            if match:
                return json.loads(match.group(0))
            raise ValueError(f"Failed to parse LLM output as JSON:\n{raw}")

    parsed = extract_json(result.raw)

    return {
        "name": name,
        "input_address": parsed.get("input_address"),
        "validated_address": parsed.get("validated_address"),
        "headquarters_address": parsed.get("headquarters_address"),
        "is_match": parsed.get("is_match"),
        "confidence": parsed.get("confidence", 0.0),
        "sources": parsed.get("sources", []),
        "reasoning": parsed.get("reasoning", ""),
        "hitl_required": parsed.get("hitl_required"),
        "human_feedback": human_feedback
    }

def validate_entity_recursive(
    name: str,
    address: Optional[str] = None,
    human_feedback: Optional[str] = None,
    processed: Optional[Set[str]] = None,
    depth: int = 0,
    max_depth: int = 5
) -> Optional[Dict[str, Any]]:
    """
    Recursively validates a partner (and its address), discovers and validates child entities,
    and returns a nested validation result structure.
    """
    processed = processed or set()
    key = name.lower().strip()
    if key in processed or depth > max_depth:
        return None
    processed.add(key)

    # Main validation for this entity (name/address)
    result = validate_partner_name_agentic(name, address, human_feedback)

    # Dynamic discovery of child entities using CrewAI agent
    child_entities_raw = get_child_entities(name, researcher)  # researcher is your CrewAI agent
    print(child_entities_raw)
    # Recursively validate each child entity
    result["child_entities"] = []
    for child in child_entities_raw:
        child_name = child.get("name")
        child_address = child.get("address")
        if child_name:
            child_result = validate_entity_recursive(
                name=child_name,
                address=child_address,
                human_feedback=None,
                processed=processed,
                depth=depth+1,
                max_depth=max_depth
            )
            if child_result:
                result["child_entities"].append(child_result)
    return result