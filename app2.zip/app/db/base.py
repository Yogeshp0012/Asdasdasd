from app.db.models.partner import Partner
