from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Float, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship
Base = declarative_base()

class Partner(Base):
    __tablename__ = "partners"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)

class PartnerValidation(Base):
    __tablename__ = "partner_validations"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    input_address = Column(String, nullable=True)
    validated_address = Column(String, nullable=True)
    headquarters_address = Column(String, nullable=True)
    is_match = Column(Boolean, nullable=True)
    confidence = Column(Float)
    sources = Column(Text)  # Store as JSON string
    reasoning = Column(Text)
    hitl_required = Column(Boolean, nullable=True)
    human_feedback = Column(Text, nullable=True)
    qa_report = Column(Text, nullable=True)
    # Optionally, add a parent_id for recursive/child relationships
    parent_id = Column(Integer, ForeignKey("partner_validations.id"), nullable=True)
    child_entities = relationship("PartnerValidation", backref="parent", remote_side=[id])
