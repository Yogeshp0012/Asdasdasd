from sqlalchemy.orm import Session
from app.db.models.partner import Partner
from app.schemas.partner import PartnerCreate

def create_partner(db: Session, partner: PartnerCreate):
    db_partner = Partner(name=partner.name, email=partner.email)
    db.add(db_partner)
    db.commit()
    db.refresh(db_partner)
    return db_partner

def get_partners(db: Session):
    return db.query(Partner).all()
