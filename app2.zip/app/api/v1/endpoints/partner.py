from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.schemas.partner import Partner, PartnerCreate, EntityValidationResult, PartnerValidationRequest
from app.services.partner_service import create_partner, get_partners
from app.db.session import get_db
from app.agents.crewai_agent import validate_entity_recursive

router = APIRouter()

@router.post("/", response_model=Partner)
def create_partner_endpoint(partner: PartnerCreate, db: Session = Depends(get_db)):
    return create_partner(db, partner)

@router.get("/", response_model=list[Partner])
def list_partners_endpoint(db: Session = Depends(get_db)):
    return get_partners(db)

@router.post("/validate", response_model=EntityValidationResult)
def validate_partner_name_endpoint(request: PartnerValidationRequest):
    result = validate_entity_recursive(
        name=request.name,
        address=request.address,
        human_feedback=request.human_feedback
    )
    return result
